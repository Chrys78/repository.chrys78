# -*- coding: UTF-8 -*-

from resources.lib.sweettv import SweetTV

if __name__ == '__main__':
    SweetTV()